
const schedules = [

  {id: 1, information: "30 March -> 10 AM"},
  {id: 2, information: "31 March -> 10 AM"},
  {id: 3, information: "1 April -> 2 PM"},
  {id: 4, information: "2 April -> 2 AM"},
  {id: 5, information: "3 April -> 10 AM"},
]

const MAX_NO_SCHEDULES = 3;

module.exports = {schedules, MAX_NO_SCHEDULES};
