

const classRecordings = [
  {id: 1, sizeInMB : 350, topic: 'NodeJS Introduction', duration : '3 Hours' },
  {id: 2, sizeInMB : 425, topic: 'MongoDB', duration : '2.5 Hours' },
  {id: 3, sizeInMB : 250, topic: 'Callbacks & Promises', duration : '2 Hours' }
]

// sizeInMB : 250, topic: 'Callbacks & Promises', duration : '2 Hours', downloadableFormats : 'mkv, mp4'



module.exports = {classRecordings};