

// Express - Web based
// HTTP Endpoints / REST


// Database - MongoDB
// Mongoose

const mongoose = require("mongoose");

// mongoose.connect();
