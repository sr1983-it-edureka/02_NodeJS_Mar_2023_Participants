
// Simple Data [Float / Decimal]
const PI = 3.14;

console.log("Value of PI is " + PI);

PI = 3.15;
