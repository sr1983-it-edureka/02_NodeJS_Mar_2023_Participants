
const players = ["Player1", "Player2", "Player3", "Player4", "Player5"];

const index = 2;
console.log(players);

players.splice(index, 2);

console.log(players);
