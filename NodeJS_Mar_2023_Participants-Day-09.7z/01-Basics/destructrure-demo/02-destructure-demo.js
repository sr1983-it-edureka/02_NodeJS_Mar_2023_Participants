
// 3rd Way
const {BankAccount, CreditCardAccount} = 
require("../module-usages/sample-modules/03-multiple-types");

let bankAccount1 = new BankAccount();
console.log(bankAccount1);

let ccAccount1 = new CreditCardAccount();
console.log(ccAccount1);

