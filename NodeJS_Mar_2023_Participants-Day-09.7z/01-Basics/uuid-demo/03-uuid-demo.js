
const {v4 : uuidv4 } = require("uuid");

const id2 = uuidv4();
console.log(id2);
