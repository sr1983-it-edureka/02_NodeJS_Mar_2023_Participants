

// Segment 1

let a = 10;
let b = 20;
console.log("Segment 1 of the program....")

// Segment 2

let x = 45;
let y = 50;
console.log("Segment 2 of the program....")


// Segment 3

try{
  const bookObject2 = JSON.parse(
    '{"name":"Harry Potter","author":"JK Rowling"}'
  );  

  console.log(bookObject2.name);
  console.log(bookObject2.author);
  
  console.log("Segment 3 -> JSON Processing....")

}catch (error){
  console.log(error);
}

// Segment 4

console.log("Segment 4 ")


// Segment 5

console.log("Segment 5 ")


// Segment 6

console.log("Segment 6 ")