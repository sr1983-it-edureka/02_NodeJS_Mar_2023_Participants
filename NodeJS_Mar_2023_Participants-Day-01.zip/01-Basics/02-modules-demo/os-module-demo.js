
// import 

// load the module
const os = require("os");

const totalMemory = os.totalmem();
console.log("Total Memory is " + totalMemory);

console.log("Total Memoery is " + os.totalmem());

const freeMemory = os.freemem();

console.log("Free memory is " + freeMemory);


// const http = require("http");