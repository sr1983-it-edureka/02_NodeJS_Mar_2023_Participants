
let age = 25;

console.log("Age is " + age);

age = 30;

console.log("Age is " + age);
