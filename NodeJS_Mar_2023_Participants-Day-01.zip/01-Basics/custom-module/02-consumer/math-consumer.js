
const math = require("../01-creator/math/math");

// 
let result = math.add(20, 35);
console.log(`Result is ${result}`);

result = math.ADDITION(20, 35);
console.log(`Result is ${result}`);

result = math.ADDITION_2(20, 35);
console.log(`Result is ${result}`);
// 2

console.log("PI is " + math.MATHS_PI);

// 3

result = math.SUBTRACTION(35, 45);
console.log(`Result is ${result}`);
