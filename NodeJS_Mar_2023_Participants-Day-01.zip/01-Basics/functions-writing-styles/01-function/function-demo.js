
// 1st way

function mergeString(s1, s2, s3){

  const mergedOutcome = s1 + " " + s2 + " " + s3;
  return mergedOutcome;
}

const outcome = mergeString("Hello", "Good", "Morning");
console.log(outcome);