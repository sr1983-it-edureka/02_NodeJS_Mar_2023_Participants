
function sayHello(){

  console.log("Hello Everyone - Welcome to the world of NodeJS");
}

sayHello();