
const uuid = require("uuid");

// const id1 = uuid.v3();
// console.log(id1);

const id2 = uuid.v4();
console.log(id2);

// const id2 = uuid.v5();
// console.log(id2);