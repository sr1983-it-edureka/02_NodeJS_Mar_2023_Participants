

class BankAccount {

}

class CreditCardAccount {

}

class MutualFundAccount {

}

// a = b
module.exports = {
  BankAccount, 
  CreditCardAccount, 
  MutualFundAccount
};
